/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "lenny"
#define BUILD_KERNEL "2.6.26-2-686"
#define BUILD_MACHINE "i686"
#define BUILD_OS "Linux"
#define BUILD_DATE "2010-02-23 14:34:17 UTC"
#define BUILD_USER "root"

