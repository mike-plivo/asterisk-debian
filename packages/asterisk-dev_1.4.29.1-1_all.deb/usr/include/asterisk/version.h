/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "1.4.29.1-1"
#define ASTERISK_VERSION_NUM 10429

